import { handlers } from "@/auth"; // Referring to the auth.ts file we just created
export const { GET, POST } = handlers;
